import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class titulo here.
 * 
 * @Augusto Sanic 20717  
 * @version 1.1 
 */
public class titulo extends Actor
{
    /**
     * Act - do whatever the titulo wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
    }
    
    
    //constructor de la imagen que contiene el titulo del juego, escalada a un tamaño mas pequeño
    public titulo(){
    
    getImage().scale(570,50);
    }
    
}
