import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class pressreset here.
 * 
 * @Augusto Sanic 20717  
 * @version 1.1 
 */
public class pressreset extends Actor
{
    /**
     * Act - do whatever the pressreset wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
    }
    //reescalado del mensaje que indica que perdieron
    public pressreset(){
        getImage().scale(700,45);
    }
}
