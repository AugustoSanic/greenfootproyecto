import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class parteinpenetrable2 here.
 * 
 * /**
 * @Augusto Sanic 20717  
 * @version 1.1 
 */

public class parteinpenetrable2 extends Actor
{
    /**
     * Act - do whatever the parteinpenetrable2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
    }
}
